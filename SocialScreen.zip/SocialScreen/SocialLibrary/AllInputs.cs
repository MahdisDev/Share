﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialLibrary
{
    public class AllInputs
    {
        private Input _input;
        public string Time { get; private set; }
        public string UserName { get; }
        public string User => _input.User;
        public string Text => _input.Text;
        public DateTime InputTime => _input.InputTime;
        public int Id => _input.Id;
        public AllInputs(Input input, ITimeBack timeBack)
        {
            _input = input;
            TimeInput(timeBack);
            UserName = $"{input.User} - {input.Text} {Time}";
        }

        public void TimeInput(ITimeBack timeBack)
        {
            Time = timeBack.GetTimeInputed(_input);
        }
    }
}
