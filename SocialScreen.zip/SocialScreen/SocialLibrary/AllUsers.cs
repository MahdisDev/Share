﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SocialLibrary
{
    public interface IInputdefinitions
    {
        int GetNextId();
    }

    class AllUsers : IInputdefinitions
    {
        private IList<User> _members = new List<User>();

        public User GetUser(string userName)
        {
            var user = _members.FirstOrDefault(u => u.Name == userName);
            if (user == null)
            {
                user = new User(userName);
                _members.Add(user);
            }
            return user;
        }

        public void Input(string userName, string text)
        {
            var timestamp = DateTime.Now;
            var user = GetUser(userName);
            user.AddInput(userName, text, timestamp, this);
        }

        public int GetNextId()
        {
            return _members.Sum(u => u.inputs.Count);
        }
    }
}
