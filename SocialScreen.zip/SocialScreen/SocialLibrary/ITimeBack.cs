﻿using System;

namespace SocialLibrary
{
    public interface ITimeBack
    {
        string GetTimeInputed(Input input);
        string TimeDifference(DateTime t1, DateTime t2);
    }
}