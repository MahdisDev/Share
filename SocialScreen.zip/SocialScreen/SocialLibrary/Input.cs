﻿using System;

namespace SocialLibrary
{
    public class Input
    {
        public Input(string user, string text, DateTime inputTime, IInputdefinitions inputdefinitions)
        {
            User = user;
            Text = text;
            InputTime = inputTime;
            Id = inputdefinitions.GetNextId();
        }
        public string User { get; }
        public string Text { get; }
        public DateTime InputTime { get; }
        public int Id { get; }
    }
}
