﻿using System.Collections.Generic;
using System.Linq;

namespace SocialLibrary
{
    class Reading
    {
        private readonly ITimeBack _timeBack;
        private AllUsers _allUsers;

        public Reading(ITimeBack timeBack, AllUsers allUsers)
        {
            _timeBack = timeBack;
            _allUsers = allUsers;
        }
        public IList<AllInputs> Read(string userName)
        {
            var user = GetUser(userName);
            return Read(user);
        }

        private IList<AllInputs> Read(User user)
        {
            var inputs = user.inputs;
            var allInputs = new List<AllInputs>();
            foreach (var input in inputs)
            {
                allInputs.Add(new AllInputs(input, _timeBack));
            }

            allInputs.Reverse();
            return allInputs;
        }

        public IList<AllInputs> Read(List<User> users, User wallOwner)
        {
            var allInputs = new List<AllInputs>();
            foreach (var user in users)
            {
                var inputs = user.inputs;
                foreach (var input in inputs)
                {
                    allInputs.Add(new AllInputs(input, _timeBack));
                }
            }
            allInputs.AddRange(Read(wallOwner));
            allInputs = allInputs.OrderByDescending(p => p.Id).ToList();
            return allInputs;
        }

        private User GetUser(string userName)
        {
            return _allUsers.GetUser(userName);
        }
    }
}
