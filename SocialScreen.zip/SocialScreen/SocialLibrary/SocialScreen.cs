﻿using System.Collections.Generic;
using System.Linq;

namespace SocialLibrary
{
    public class SocialScreen
    {
        private readonly Writing _writing;
        private readonly Reading _reading;
        private IDictionary<User, List<User>> _following;
        private AllUsers _allUsers;

        public SocialScreen(ITimeBack timeBack = null)
        {
            if (timeBack == null)
            {
                timeBack = new TimeBack();
            }
            _allUsers = new AllUsers();
            _following = new Dictionary<User, List<User>>();
            _writing = new Writing(_allUsers);
            _reading = new Reading(timeBack, _allUsers);
        }

        public void Input(string userName, string text)
        {
            _writing.Post(userName, text);
        }

        public IList<AllInputs> ReadInput(string userName)
        {
            return _reading.Read(userName);
        }

        public IList<AllInputs> GetScreen(string userName)
        {
            var follower = _allUsers.GetUser(userName);
            if (_following.ContainsKey(follower))
            {
                var following = _following[follower];

                return _reading.Read(following, follower);
            }
            return _reading.Read(userName);
        }

        public void Follow(string followerUserName, string target)
        {
            var follower = _allUsers.GetUser(followerUserName);
            if (_following.ContainsKey(follower) == false)
            {
                _following.Add(follower, new List<User>());
            }

            var followerFollows = _following.Single(f => f.Key == follower);
            var followingUser = _allUsers.GetUser(target);
            followerFollows.Value.Add(followingUser);
        }
    }
}
