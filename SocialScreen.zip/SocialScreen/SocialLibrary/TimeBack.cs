﻿using System;
using static System.String;

namespace SocialLibrary
{
    public class TimeBack : ITimeBack
    {
        public string GetTimeInputed(Input input)
        {
            return TimeDifference(input.InputTime, DateTime.Now);

        }

        public string TimeDifference(DateTime t1, DateTime t2)
        {
            var timeDiff = t2.Subtract(t1);
            if (timeDiff.Days >= 1)
            {
                return " - old post";
            }
            if (timeDiff.Hours > 0)
            {
                return TimeFormat(timeDiff.Hours, "hour");
            }
            if (timeDiff.Minutes > 0)
            {
                var value = timeDiff.Minutes;
                var timeUnitSingular = "minute";
                return TimeFormat(value, timeUnitSingular);
            }
            return TimeFormat(timeDiff.Seconds, "second");

        }

        private static string TimeFormat(int value, string unit)
        {
            var plural = value == 1 ? Empty : "s";

            return $"({value} {unit}{plural} ago)";
        }
    }
}
