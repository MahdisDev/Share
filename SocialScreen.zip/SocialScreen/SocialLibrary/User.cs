﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SocialLibrary
{
    class User
    {
        public string Name { get; }
        public IList<Input> inputs { get; } = new List<Input>();

        public User(string name)
        {
            Name = name;
        }

        public void AddInput(string userName, string text, DateTime timestamp, IInputdefinitions inputdefinitions)
        {
            inputs.Add(new Input(Name, text, timestamp, inputdefinitions));
        }
    }
}
