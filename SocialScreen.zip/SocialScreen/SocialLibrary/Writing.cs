﻿namespace SocialLibrary
{
    class Writing
    {
        private AllUsers _allUsers;

        public Writing(AllUsers allUsers)
        {
            _allUsers = allUsers;
        }

        public void Post(string userName, string text)
        {
            _allUsers.Input(userName, text);
        }
    }
}
