﻿using System;

namespace SocialScreenUI
{
    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Social Media: Press X to exit!");
            var screenReader = new ScreenReader();
            var input = String.Empty;
            while (input != "x")
            {
                input = Console.ReadLine();
                var output = screenReader.AcceptInput(input);
                foreach (var line in output)
                {
                    Console.WriteLine(line);
                }

            }
        }
    }
}
