﻿using SocialLibrary;
using System.Collections.Generic;
using System.Linq;

namespace SocialScreenUI
{
    public class ScreenReader
    {
        private SocialScreen _socialScreen;
        public ScreenReader(ITimeBack timeback = null)
        {
            _socialScreen = new SocialScreen(timeback);
        }

        public List<string> AcceptInput(string msg)
        {
            if (Posting(msg, out var inputlist)) { return inputlist; }

            if (Reading(msg, out var firstInput)) { return firstInput; }

            if (Following(msg, out var followlist)) { return followlist; }

            if (Wall(msg, out var secondInput)) { return secondInput; }


            return new List<string>();
        }

        private bool Posting(string input, out List<string> list)
        {
            list = new List<string>();
            var delimiter = "->";
            var symbol = input.Split(delimiter);
            if (symbol.Length == 2)
            {
                _socialScreen.Input(symbol[0].Trim(), symbol[1].Trim());
                {
                    return true;
                }
            }

            return false;
        }

        private bool Reading(string input, out List<string> list)
        {
            list = new List<string>();
            if (input.IndexOf(" ") < 0)
            {
                var responses = _socialScreen.ReadInput(input);
                {
                    list = responses.Select(r => $"{r.Text} {r.InputTime}").ToList();
                    return true;
                }
            }

            return false;
        }

        private bool Following(string input, out List<string> list)
        {
            list = new List<string>();
            var delimiter = "follows";
            var follows = input.Split(delimiter);
            if (follows.Length == 2)
            {
                _socialScreen.Follow(follows[0].Trim(), follows[1].Trim());
                {
                    return true;
                }
            }

            return false;
        }

        private bool Wall(string input, out List<string> list)
        {
            list = new List<string>();
            var delimiter = "wall";
            if (input.IndexOf(delimiter) > 0)
            {
                var responses = _socialScreen.GetScreen(input.Replace(delimiter, string.Empty));
                {
                    list = responses.Select(r => r.UserName).ToList();
                    return true;
                }
            }

            return false;
        }
    }
}
